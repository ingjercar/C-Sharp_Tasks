Justificación de la POO:
En este proyecto, aplicamos la Programación Orientada a Objetos (POO) para organizar y estructurar el código de una manera más lógica y modular. La POO se basa en cuatro pilares principales: encapsulamiento, herencia, polimorfismo y abstracción. Aunque no usamos todos, los conceptos clave aquí son la abstracción y el encapsulamiento.

Abstracción: Creamos clases como Admin, Concierto, Cliente, Tiket e HistorialCompra que representan entidades del mundo real. Estas clases no son solo variables; son "plantillas" o "modelos" que encapsulan tanto los datos (atributos) como las acciones (métodos) que se pueden realizar con ellos. Por ejemplo, la clase Concierto abstrae la idea de un concierto, incluyendo sus propiedades (como nombre, ciudad y fechaConcierto) y sus comportamientos (listarConciertos).

Encapsulamiento: Agrupamos los datos (atributos) y los métodos que operan sobre esos datos en una sola unidad: la clase. Por ejemplo, en la clase Cliente, los atributos como id, nombre, email, etc., están encapsulados con métodos como registrar() y editarCliente(). Esto protege los datos de ser manipulados directamente y asegura que solo se pueda acceder a ellos a través 
de los métodos definidos en la clase. Esto ayuda a mantener la integridad y la consistencia de la información.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

OOP Rationale:
In this project, we applied Object-Oriented Programming (OOP) to organize and structure the code in a more logical and modular way. OOP is based on four main pillars: encapsulation, inheritance, polymorphism, and abstraction. Although we didn't use all of them, the key concepts here are abstraction and encapsulation.

Abstraction: We created classes like Admin, Concert, Customer, Ticket, and PurchaseHistory that represent real-world entities. These classes aren't just variables; they're "templates" or "models" that encapsulate both the data (attributes) and the actions (methods) that can be performed on them. For example, the Concert class abstracts the idea of ​​a concert, including its properties (such as name, city, and concertDate) and its behaviors (listConcerts).

Encapsulation: We group the data (attributes) and the methods that operate on that data into a single unit: the class. For example, in the Customer class, attributes such as id, name, email, etc., are encapsulated with methods like register() and editCustomer(). This protects the data from direct manipulation and ensures that it can only be accessed through the methods defined in the class. This helps maintain data integrity and consistency.